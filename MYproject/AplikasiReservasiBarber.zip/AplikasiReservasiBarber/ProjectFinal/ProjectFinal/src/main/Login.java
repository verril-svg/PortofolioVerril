package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.User;
import util.Connect;

public class Login extends Application {

	BorderPane bp;
	GridPane gp;

	Label loginLabel;
	Label emailLabel;
	Label passLabel;

	TextField emailTf;
	PasswordField passPf;

	Button loginBtn;

	Hyperlink registerLink;
	Alert alert;

	private void initialize() {
		bp = new BorderPane();
		gp = new GridPane();

		loginLabel = new Label("Login");

		emailLabel = new Label("Email");
		emailTf = new TextField();
		emailTf.setPromptText("Input your email here");
		emailTf.setPrefWidth(300);

		passLabel = new Label("Password");
		passPf = new PasswordField();
		passPf.setPromptText("Input your password here");
		passPf.setPrefWidth(300);

		loginBtn = new Button("Login");
		loginBtn.setPrefSize(80, 40);

		registerLink = new Hyperlink("Don't have an account yet? Register Here!");
	}

	private void setComponent() {
	    gp.add(loginLabel, 0, 0, 2, 1);
	    gp.setHalignment(loginLabel, HPos.CENTER);

	    gp.add(emailLabel, 0, 1);
	    gp.add(emailTf, 0, 2, 2, 1);

	    gp.add(passLabel, 0, 3);
	    gp.add(passPf, 0, 4, 2, 1);

	    gp.add(loginBtn, 0, 5, 2, 1);
	    gp.setHalignment(loginBtn, HPos.CENTER);

	    gp.add(registerLink, 0, 6, 2, 1);
	    gp.setHalignment(registerLink, HPos.CENTER);

	    gp.setPadding(new Insets(20, 20, 20, 20));
	    gp.setVgap(5);
	    gp.setHgap(5);
	    gp.setAlignment(Pos.CENTER);

	    bp.setCenter(gp);

	    loginLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
	    registerLink.setStyle("-fx-text-fill: #1E90FF; -fx-underline: true;");
	}


	private void showAlert(Alert.AlertType type, String title, String msg) {
		alert = new Alert(type);
		alert.setTitle(title);
		alert.setContentText(msg);
		alert.showAndWait();
	}

	private void eventHandler(Stage primaryStage) {
		loginBtn.setOnAction(e -> {
			String email = emailTf.getText();
			String pass = passPf.getText();
			boolean role = checkRole(email);

			if (email.isEmpty()) {
				showAlert(AlertType.ERROR, "Login Error", "Email cannot be empty");
			} else if (pass.isEmpty()) {
				showAlert(AlertType.ERROR, "Login Error", "Password cannot be empty");
			} else if (!checkCredential(email, pass)) {
				showAlert(AlertType.ERROR, "Login Error", "Credentials are invalid");
			} else {
				String username = getUser(email);
				if (!role) {
					MenuAdmin reservePage = new MenuAdmin(username);
					try {
						reservePage.start(primaryStage);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				} else {
					MenuUser reservePage = new MenuUser(username);
					try {
						reservePage.start(primaryStage);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});

		registerLink.setOnAction(e -> {
			Register registerPage = new Register();
			try {
				registerPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
	}

	private String getUser(String email) {
		String query = "SELECT Username FROM msuser WHERE UserEmail = ?";
		
		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)){
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				return rs.getString("Username");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private boolean checkRole(String uEmail) {
		String query = "SELECT UserRole FROM msuser WHERE UserEmail = ? LIMIT 1";
		
		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
		    ps.setString(1, uEmail);
		    ResultSet rs = ps.executeQuery();
		    if (rs.next() && "Admin".equals(rs.getString("UserRole"))) {
		        return false;
		    }
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return true;
	}

	private boolean checkCredential(String uEmail, String uPassword) {
		String query = "SELECT * FROM msuser WHERE UserEmail = ? LIMIT 1";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, uEmail);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String pass = rs.getString("UserPassword");
				if (uPassword.equals(pass)) {
					return true;
				}
			}
		} catch (SQLException e) {
			System.out.println("Database error: " + e.getMessage());
			e.printStackTrace();
		}

		return false;
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		initialize();
		setComponent();
		eventHandler(primaryStage);

		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();

	}

}
