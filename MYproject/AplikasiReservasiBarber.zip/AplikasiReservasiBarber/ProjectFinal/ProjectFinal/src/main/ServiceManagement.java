package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.ServiceType;
import model.ServisMene;
import util.Connect;

public class ServiceManagement extends Application {

	BorderPane bp;
	VBox leftVBox, rightVBox;
	Label SMLabel, ServiceLabel, ServicePrice, ServiceName, ServiceType, ServiceDuration;

	MenuBar menuBar;
	Menu fileMenu;
	MenuItem serviceManagement, reservationManagement, logOut;
	TextField reserveTimeTf;
	TextField tfname, tfprice, tfduration;
	DatePicker datePicker;
	TableView<ServisMene> tv;
	ListView<String> lv;
	Alert alert;

	Button addBtn, updateBtn, deleteBtn;
	ComboBox<ServiceType> comboBox;
	HBox typeHbox;

	String username;
	List<ServiceType> serviceTypes;
	List<ServisMene> list;

	public ServiceManagement() {
		this.username = "null";
	}

	public ServiceManagement(String username) {
		this.username = (username == null || username.isEmpty()) ? "null" : username;
	}

	private void initialize() {
		bp = new BorderPane();
		list = new ArrayList<>();

		menuBar = new MenuBar();
		fileMenu = new Menu("Menu");
		serviceManagement = new MenuItem("Service Management");
		reservationManagement = new MenuItem("Reservation Management");
		logOut = new MenuItem("Log Out");

		SMLabel = new Label("Service Management ");
		SMLabel.setStyle("-fx-font-size: 25px; -fx-font-weight: bold;");

		ServiceLabel = new Label("Service List");
		ServiceLabel.setStyle(" -fx-font-weight: bold;");

		tv = new TableView<>();
		tv.setPlaceholder(new Label("No services available"));

		serviceTypes = new ArrayList<>();

		TableColumn<ServisMene, String> idColumn = new TableColumn<>("Service ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

		TableColumn<ServisMene, String> idtypeColumn = new TableColumn<>("Service Type ID");
		idtypeColumn.setCellValueFactory(new PropertyValueFactory<>("typeid"));

		TableColumn<ServisMene, String> nameColumn = new TableColumn<>("Service Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

		TableColumn<ServisMene, String> priceColumn = new TableColumn<>("Service Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

		TableColumn<ServisMene, String> durationColumn = new TableColumn<>("Service Duration");
		durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));

		tv.getColumns().addAll(idColumn, idtypeColumn, nameColumn, priceColumn, durationColumn);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		tv.setPrefHeight(350);
		tv.setPrefWidth(500);
		comboBox = new ComboBox<>();
		loadCombo();

		ServiceName = new Label("Service Name");
		tfname = new TextField();
		tfname.setPromptText("Input service Name Here");
		tfprice = new TextField();
		tfprice.setPromptText("Input service Price Here");
		tfduration = new TextField();
		tfduration.setPromptText("Input service duration Here");

		ServiceType = new Label("Service Type");

		ServicePrice = new Label("Service Price");

		ServiceDuration = new Label("Service Duration");

		addBtn = new Button("Add");
		addBtn.setPrefSize(250, 5);

		updateBtn = new Button("Update");
		updateBtn.setPrefSize(250, 5);

		deleteBtn = new Button("Delete");
		deleteBtn.setPrefSize(250, 5);

		leftVBox = new VBox(5, SMLabel, ServiceLabel, tv);
		leftVBox.setAlignment(Pos.CENTER_LEFT);

		rightVBox = new VBox(5, ServiceName, tfname, ServiceType, comboBox, ServicePrice, tfprice, ServiceDuration,
				tfduration, addBtn, updateBtn, deleteBtn);
		rightVBox.setAlignment(Pos.CENTER_LEFT);

		HBox mainContent = new HBox(20, leftVBox, rightVBox);
		mainContent.setAlignment(Pos.CENTER);
		
		bp.setCenter(mainContent);
	}

	private void setComponent() {
		fileMenu.getItems().addAll(serviceManagement, reservationManagement, logOut);
		menuBar.getMenus().add(fileMenu);
		bp.setTop(menuBar);

	}

	private void eventHandler(Stage primaryStage) {
		serviceManagement.setOnAction(e -> {
            ServiceManagement rsPage = new ServiceManagement(username);
            try {
                rsPage.start(primaryStage);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        });
        
        reservationManagement.setOnAction(e -> {
            ReservationManagement rsPage = new ReservationManagement(username);
            try {
                rsPage.start(primaryStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        
        logOut.setOnAction(e -> {
            Login loginPage = new Login();
            try {
                loginPage.start(primaryStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        
		addBtn.setOnAction(e -> {
			String name = tfname.getText();
			String type = comboBox.getValue() != null ? comboBox.getValue().getName() : "";
			String typeid = serviceType(type);
			String price = tfprice.getText();
			String duration = tfduration.getText();
			if (name.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Service name cannot be empty");
				return;
			}

			if (!checkUniqueService(name)) {
				showAlert(AlertType.ERROR, "Error", "Service already exists");
				return;
			}
			String id = generateID();
			
			insertService(id, typeid, name, price, duration);
			showAlert(AlertType.INFORMATION, "Success", "Service is successfully added");
			tv.getItems().clear();
			loadDatabase();
		});

		updateBtn.setOnAction(e -> {
			ServisMene selected = tv.getSelectionModel().getSelectedItem();
			String name = tfname.getText();
			String type = comboBox.getValue() != null ? comboBox.getValue().getName() : "";
			String typeid = serviceType(type);
			String price = tfprice.getText();
			String duration = tfduration.getText();

			if (selected == null) {
				showAlert(AlertType.ERROR, "Error", "There is no service selected");
				return;
			}

			if (name.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Service name cannot be empty");
				return;
			}

			if (!checkUniqueService(name)) {
				showAlert(AlertType.ERROR, "Error", "Service already exists");
				return;
			}
			String id = selected.getId();

			updateService(id, typeid, name, price, duration);
			showAlert(AlertType.INFORMATION, "Success", "Service is successfully updated");
			tv.getItems().clear();
			loadDatabase();
		});

		deleteBtn.setOnAction(e -> {
			ServisMene selected = tv.getSelectionModel().getSelectedItem();
			if (selected == null) {
				showAlert(AlertType.ERROR, "Error", "There is no service selected");
				return;
			}

			String id = selected.getId();

			deleteService(id);
			showAlert(AlertType.INFORMATION, "Success", "Service is successfully deleted");
			tv.getItems().clear();
			loadDatabase();
		});
		
		

	}

	private String serviceType(String type) {
		switch (type) {
		case "Haircut":
			return "ST001";
		case "Hair Perming":
			return "ST002";
		case "Hair Coloring":
			return "ST003";
		case "Hair Treatment":
			return "ST004";
		case "Hair Tattoo":
			return "ST005";
		default:
			return "Unknown";
		}
	}

	private String generateID() {
		String baseID = "SV001";

		try {
			ResultSet rs = Connect.getConnection()
					.executeQuery("SELECT MAX(CAST(SUBSTRING(ServiceID, 3) AS UNSIGNED)) AS NewID FROM msservice");
			if (rs.next()) {
				int newID = rs.getInt("NewID");
				baseID = String.format("SV%03d", newID + 1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return baseID;
	}

	private void deleteService(String id) {
		String query = "DELETE FROM msservice WHERE ServiceID = ?";

		try {
			PreparedStatement ps = Connect.getConnection().prepareStatement(query);
			ps.setString(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void updateService(String id, String typeid, String name, String price, String duration) {
		String query = "UPDATE msservice "
				+ "SET ServiceTypeID = ?, ServiceName = ?, ServicePrice = ?, ServiceDuration = ? "
				+ "WHERE ServiceID = ?";

		try {
			PreparedStatement ps = Connect.getConnection().prepareStatement(query);
			ps.setString(1, typeid);
			ps.setString(2, name);
			ps.setString(3, price);
			ps.setString(4, duration);
			ps.setString(5, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void insertService(String id, String typeid, String name, String price, String duration) {
		String query = "INSERT INTO msservice (ServiceID, ServiceTypeID, ServiceName, ServicePrice, ServiceDuration) "
				+ "VALUES (?, ?, ?, ?, ?)";

		try {
			PreparedStatement ps = Connect.getConnection().prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, typeid);
			ps.setString(3, name);
			ps.setString(4, price);
			ps.setString(5, duration);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private boolean checkUniqueService(String nama) {
		String query = "SELECT ServiceName FROM msservice WHERE ServiceName = ?";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, nama);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	private void showAlert(Alert.AlertType type, String title, String msg) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setContentText(msg);
		alert.showAndWait();
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		initialize();
		setComponent();
		eventHandler(primaryStage);
		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();

		loadDatabase();
	}

	private void loadCombo() {
		comboBox.getItems().clear();
		ResultSet rs = Connect.getConnection().executeQuery("SELECT * FROM msservicetype");

		try {
			while (rs.next()) {
				String id = rs.getString("ServiceTypeID");
				String name = rs.getString("ServiceTypeName");

				comboBox.getItems().add(new ServiceType(id, name));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void loadDatabase() {
		ResultSet rs = Connect.getConnection().executeQuery("SELECT * FROM msservice");
		try {
			while (rs.next()) {
				String id = rs.getString("ServiceID");
				String typeid = rs.getString("ServiceTypeID");
				String name = rs.getString("ServiceName");
				String price = rs.getString("ServicePrice");
				String duration = rs.getString("ServiceDuration");
				tv.getItems().add(new ServisMene(id, typeid, name, price, duration));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
