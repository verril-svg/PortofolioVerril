package main;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.User;

public class MenuAdmin extends Application {
	BorderPane bp;
	GridPane gp;

	MenuBar menuBar;
	Menu fileMenu;
	MenuItem serviceManagement;
	MenuItem reservationManagement;
	MenuItem logOut;

	Label userLabel;
	
	String username;
	
	public MenuAdmin(String username) {
		this.username = username;
	}

	private void initialize() {
		bp = new BorderPane();
		gp = new GridPane();

		menuBar = new MenuBar();
		fileMenu = new Menu("Menu");
		serviceManagement = new MenuItem("Service Management");
		reservationManagement = new MenuItem("Reservation Management");
		logOut = new MenuItem("Log Out");
	}

	private void setComponent() {
		fileMenu.getItems().addAll(serviceManagement, reservationManagement, logOut);
		menuBar.getMenus().add(fileMenu);
		bp.setTop(menuBar);

		userLabel = new Label("Admin Page");
		userLabel.setStyle(
				"-fx-text-fill: black; -fx-font-size: 24px; -fx-text-stroke: white;");

		gp.add(userLabel, 0, 0);
		gp.setHalignment(userLabel, HPos.CENTER);
		gp.setAlignment(Pos.CENTER);

		bp.setCenter(gp);
	}

	private void eventHandler(Stage primaryStage) {
		serviceManagement.setOnAction(e -> {
			ServiceManagement smPage = new ServiceManagement(username);
			try {
				smPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		reservationManagement.setOnAction(e -> {
			ReservationManagement rmPage = new ReservationManagement(username);
			try {
				rmPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		logOut.setOnAction(e -> {
			Login loginPage = new Login();
			try {
				loginPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		});
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		initialize();
		setComponent();
		eventHandler(primaryStage);

		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();
	}
}
