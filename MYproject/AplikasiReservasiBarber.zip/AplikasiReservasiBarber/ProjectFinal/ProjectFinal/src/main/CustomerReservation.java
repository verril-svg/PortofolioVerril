package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.ReservationHeader;
import model.Service;
import util.Connect;

public class CustomerReservation extends Application {

	BorderPane bp;
	GridPane gp;
	MenuBar menuBar;
	Menu fileMenu;
	MenuItem reserveService, customerReservation, logOut;

	Label userLabel, historyLabel, idLabel, dateLabel, startTimeLabel, endTimeLabel, statusLabel;

	Button cancelBtn;

	TableView<ReservationHeader> tv;
	ObservableList<ReservationHeader> rhData;

	VBox vboxL, vboxR;

	HBox hbox;

	String username;

	public CustomerReservation() {
		this.username = "null";
	}

	public CustomerReservation(String username) {
		this.username = (username == null || username.isEmpty()) ? "null" : username;
	}

	private void initialize() {
		bp = new BorderPane();
		gp = new GridPane();

		menuBar = new MenuBar();
		fileMenu = new Menu("Menu");
		reserveService = new MenuItem("Reserve Service");
		customerReservation = new MenuItem("Customer Reservation");
		logOut = new MenuItem("Log Out");

		userLabel = new Label(username + "'s Reservation");
		userLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

		historyLabel = new Label("Reservation History");
		historyLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");

		tv = new TableView<>();
		rhData = FXCollections.observableArrayList();

		TableColumn<ReservationHeader, String> idColumn = new TableColumn<>("ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<>("reservationID"));

		TableColumn<ReservationHeader, Date> dateColumn = new TableColumn<>("Date");
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));

		TableColumn<ReservationHeader, Time> startTimeColumn = new TableColumn<>("Start Time");
		startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startTime"));

		TableColumn<ReservationHeader, Time> endTimeColumn = new TableColumn<>("End Time");
		endTimeColumn.setCellValueFactory(new PropertyValueFactory<>("endTime"));

		TableColumn<ReservationHeader, String> statusColumn = new TableColumn<>("Status");
		statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

		tv.getColumns().addAll(idColumn, dateColumn, startTimeColumn, endTimeColumn, statusColumn);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		tv.setPrefHeight(350);

		idLabel = new Label("ID: ");
		idLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold");

		dateLabel = new Label("Date: ");
		dateLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold");

		startTimeLabel = new Label("Start Time: ");
		startTimeLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold");

		endTimeLabel = new Label("End Time: ");
		endTimeLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold");

		statusLabel = new Label("Status: ");
		statusLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold");

		cancelBtn = new Button("Cancel");
		cancelBtn.setPrefWidth(100);

		vboxL = new VBox(20, userLabel, historyLabel, tv);
		vboxL.setAlignment(Pos.TOP_LEFT);
		vboxL.setPrefWidth(500);

		vboxR = new VBox(20, idLabel, dateLabel, startTimeLabel, endTimeLabel, statusLabel, cancelBtn);
		vboxR.setAlignment(Pos.CENTER_LEFT);
		vboxR.setPrefWidth(250);

		hbox = new HBox(20, vboxL, vboxR);
		hbox.setAlignment(Pos.CENTER);
		hbox.setPadding(new javafx.geometry.Insets(20));
	}

	private void setComponent() {
		fileMenu.getItems().addAll(reserveService, customerReservation, logOut);
		menuBar.getMenus().add(fileMenu);
		bp.setTop(menuBar);

		bp.setCenter(hbox);
	}

	private void eventHandler(Stage primaryStage) {
		reserveService.setOnAction(e -> {
			ReserveService rsPage = new ReserveService(username);
			try {
				rsPage.start(primaryStage);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		});

		customerReservation.setOnAction(e -> {
			CustomerReservation crPage = new CustomerReservation(username);
			try {
				crPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		logOut.setOnAction(e -> {
			Login loginPage = new Login();
			try {
				loginPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		cancelBtn.setOnAction(e -> {
			ReservationHeader selected = tv.getSelectionModel().getSelectedItem();

			if (selected == null) {
				showAlert(AlertType.ERROR, "Error", "No reservation is selected");
				return;
			}

			String reservationStatus = selected.getStatus();

			if ("Cancelled".equalsIgnoreCase(reservationStatus)) {
				showAlert(AlertType.ERROR, "Error", "Reservation is already cancelled");
				return;
			}

			if ("Finished".equalsIgnoreCase(reservationStatus)) {
				showAlert(AlertType.ERROR, "Error", "Cannot cancel finished reservation");
				return;

			}

			String query = "UPDATE reservationheader SET ReservationStatus = 'Cancelled' " + "WHERE ReservationID = '"
					+ selected.getReservationID() + "'";
			Connect.getConnection().executeUpdate(query);

			loadDatabase();
			showAlert(AlertType.INFORMATION, "Success", "Your reservation is successfully cancelled");
		});

	}

	private void showAlert(Alert.AlertType type, String title, String msg) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setContentText(msg);
		alert.showAndWait();
	}

	public void viewSelectedData() {
		loadDatabase();

		tv.setItems(rhData);

		tv.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ReservationHeader>() {
			@Override
			public void changed(ObservableValue<? extends ReservationHeader> observable, ReservationHeader data1,
					ReservationHeader data2) {
				if (data2 != null) {
					idLabel.setText("ID: " + data2.getReservationID());
					dateLabel.setText("Date: " + data2.getDate());
					startTimeLabel.setText("Start Time: " + data2.getStartTime());
					endTimeLabel.setText("End Time: " + data2.getEndTime());
					statusLabel.setText("Status: " + data2.getStatus());
				} else {
					idLabel.setText("ID: ");
					dateLabel.setText("Date: ");
					startTimeLabel.setText("Start Time: ");
					endTimeLabel.setText("End Time: ");
					statusLabel.setText("Status: ");
				}
			}
		});
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		initialize();
		setComponent();
		viewSelectedData();
		eventHandler(primaryStage);

		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();

		loadDatabase();
	}
	
	private String getUserID(String use) {
		String query = "SELECT UserID FROM msuser WHERE Username = ?";
		
		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)){
			ps.setString(1, use);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				return rs.getString("UserID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void loadDatabase() {
		String query = "SELECT * FROM reservationheader WHERE UserID = '" + getUserID(username) + "'";
		
		ResultSet rs = Connect.getConnection().executeQuery(query);
		
		rhData.clear();

		try {
			while (rs.next()) {
				String id = rs.getString("ReservationID");
				String uid = rs.getString("UserID");
				Date date = rs.getDate("ReservationDate");
				Time start = rs.getTime("StartReservationTime");
				Time end = rs.getTime("EndReservationTime");
				String status = rs.getString("ReservationStatus");
				tv.getItems().add(new ReservationHeader(id, uid, date, start, end, status));			       
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
