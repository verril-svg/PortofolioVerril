package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.User;
import util.Connect;
import javafx.scene.layout.BorderPane;

public class Register extends Application {

	BorderPane bp;
	GridPane gp;

	Label registerLabel;
	Label usernameLabel;
	Label emailLabel;
	Label passLabel;
	Label confirmPassLabel;
	Label phoneNumberLabel;

	TextField usernameTf;
	TextField emailTf;
	PasswordField passPf;
	PasswordField confirmPassPf;
	TextField phoneNumberTf;

	RadioButton maleBtn;
	RadioButton femaleBtn;
	ToggleGroup genderToggle;
	HBox genderBox;

	Button registerBtn;

	Hyperlink loginLink;

	Alert alert;

	private void initialize() {
		bp = new BorderPane();
		gp = new GridPane();

		registerLabel = new Label("Register");
		registerLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

		usernameLabel = new Label("Username");
		usernameTf = new TextField();
		usernameTf.setPromptText("Input your username here");
		usernameTf.setMaxWidth(300);

		emailLabel = new Label("Email");
		emailTf = new TextField();
		emailTf.setPromptText("Input your email here");
		emailTf.setMaxWidth(300);

		passLabel = new Label("Password");
		passPf = new PasswordField();
		passPf.setPromptText("Input your password here");
		passPf.setMaxWidth(300);

		confirmPassLabel = new Label("Confirm Password");
		confirmPassPf = new PasswordField();
		confirmPassPf.setPromptText("Confirm your password here");
		confirmPassPf.setMaxWidth(300);

		phoneNumberLabel = new Label("Phone Number");
		phoneNumberTf = new TextField();
		phoneNumberTf.setPromptText("Input your phone number here");
		phoneNumberTf.setMaxWidth(300);

		genderBox = new HBox(10);
		genderBox.setAlignment(Pos.CENTER_LEFT);
		genderToggle = new ToggleGroup();

		maleBtn = new RadioButton("Male");
		femaleBtn = new RadioButton("Female");
		maleBtn.setToggleGroup(genderToggle);
		femaleBtn.setToggleGroup(genderToggle);
		genderBox.getChildren().addAll(maleBtn, femaleBtn);

		registerBtn = new Button("Register");
		registerBtn.setPrefSize(80, 40);

		loginLink = new Hyperlink("Already have an account? Click here to login!");
		loginLink.setStyle("-fx-text-fill: #1E90FF; -fx-underline: true;");
	}

	private void setComponent() {
	    gp.setPadding(new Insets(20, 20, 20, 20));
	    gp.setVgap(10);
	    gp.setHgap(10);

	    gp.add(registerLabel, 0, 0, 2, 1);
	    gp.setHalignment(registerLabel, HPos.CENTER);

	    gp.add(usernameLabel, 0, 1);
	    gp.add(usernameTf, 0, 2, 2, 1);

	    gp.add(emailLabel, 0, 3);
	    gp.add(emailTf, 0, 4, 2, 1);

	    gp.add(passLabel, 0, 5);
	    gp.add(passPf, 0, 6, 2, 1);

	    gp.add(confirmPassLabel, 0, 7);
	    gp.add(confirmPassPf, 0, 8, 2, 1);

	    gp.add(phoneNumberLabel, 0, 9);
	    gp.add(phoneNumberTf, 0, 10, 2, 1);

	    gp.add(genderBox, 0, 12, 2, 1);

	    gp.add(registerBtn, 0, 13, 2, 1);
	    gp.setHalignment(registerBtn, HPos.CENTER);

	    gp.add(loginLink, 0, 14, 2, 1);
	    gp.setHalignment(loginLink, HPos.CENTER);

	    gp.setAlignment(Pos.CENTER);
	    bp.setCenter(gp);
	}

	
	private void showAlert(Alert.AlertType type, String title, String msg) {
		alert = new Alert(type);
		alert.setTitle(title);
		alert.setContentText(msg);
		alert.showAndWait();
	}

	public static void main(String[] args) {
		launch(args);
	}

	private void eventHandler(Stage primaryStage) {
		registerBtn.setOnAction(e -> {
			String username = usernameTf.getText();
			String email = emailTf.getText();
			String pass = passPf.getText();
			String confirmPass = confirmPassPf.getText();
			String unphoneNumber = phoneNumberTf.getText();
			String phoneNumber = formatPhoneNumber(unphoneNumber);
			Toggle selectedToggle = genderToggle.getSelectedToggle();
			String gender = null;
			String role = null;

			String id = generateID();

			if (username.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Username can't be empty");
			} else if (username.length() < 5 || username.length() > 30) {
				showAlert(AlertType.ERROR, "Error", "Username must be 5 - 30 characters");
			} else if (!usernameUnique(username)) {
				showAlert(AlertType.ERROR, "Error", "Username must be unique");
			} else if (email.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Email can't be empty");
			} else if (!email.endsWith("@gmail.com")) {
				showAlert(AlertType.ERROR, "Error", "Email must end with @gmail.com");
			} else if (!emailUnique(email)) {
				showAlert(AlertType.ERROR, "Error", "Email has already been used");
			} else if (pass.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Password can't be empty");
			} else if (!isAlphanumeric(pass)) {
				showAlert(AlertType.ERROR, "Error", "Password must be alphanumeric");
			} else if (pass.length() < 8 || pass.length() > 15) {
				showAlert(AlertType.ERROR, "Error", "Password must be 8 - 15 characters");
			} else if (confirmPass.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Confirm password can't be empty");
			} else if (!confirmPass.equals(pass)) {
				showAlert(AlertType.ERROR, "Error", "Password must be the same as confirm password");
			} else if (unphoneNumber.isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "Phone number can't be empty");
			} else if (unphoneNumber.length() < 9 || unphoneNumber.length() > 13) {
				showAlert(AlertType.ERROR, "Error", "Phone number must be 9 - 13 characters");
			} else if (!unphoneNumber.startsWith("62")) {
				showAlert(AlertType.ERROR, "Error", "Phone number must start with 62");
			} else if (!phoneNumberUnique(phoneNumber)) {
				showAlert(AlertType.ERROR, "Error", "PhoneNumber has already been used");
			} else if (selectedToggle == null) {
				showAlert(AlertType.ERROR, "Error", "Gender must be selected");
			} else {
				if (username.toLowerCase().contains("admin")) {
					role = "Admin";
				} else {
					role = "User";
				}

				System.out.println("done");
				RadioButton selected = (RadioButton) selectedToggle;
				gender = selected.getText();

				insertData(id, username, pass, email, role, gender, phoneNumber);

				usernameTf.clear();
				emailTf.clear();
				passPf.clear();
				confirmPassPf.clear();
				phoneNumberTf.clear();
				genderToggle.selectToggle(null);

				Login loginPage = new Login();
				try {
					loginPage.start(primaryStage);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});

		loginLink.setOnAction(e -> {
			Login loginPage = new Login();
			try {
				loginPage.start(primaryStage);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});

	}

	private boolean isAlphanumeric(String no) {
		boolean angka = false;
		boolean huruf = false;
		for (int i = 0; i < no.length(); i++) {
			char c = no.charAt(i);
			if (((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) {
				huruf = true;
			} else if (c >= '0' && c <= '9') {
				angka = true;
			} else {
				return false;
			}
		}
		return huruf && angka;
	}

	private String generateID() {
		String baseID = "US001";

		try {
			ResultSet rs = Connect.getConnection()
					.executeQuery("SELECT MAX(CAST(SUBSTRING(UserID, 3) AS UNSIGNED)) AS NewID FROM msuser");
			if (rs.next()) {
				int newID = rs.getInt("NewID");
				baseID = String.format("US%03d", newID + 1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return baseID;
	}

	private String formatPhoneNumber(String ponnum) {
		if (ponnum.startsWith("62")) {
			return "0" + ponnum.substring(2);
		}
		return ponnum;
	}

	private boolean phoneNumberUnique(String ponnum) {
		String query = "SELECT * FROM msuser WHERE UserPhoneNumber = ? LIMIT 1";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, ponnum);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	private boolean usernameUnique(String usernem) {
		String query = "SELECT * FROM msuser WHERE Username = ? LIMIT 1";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, usernem);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	private boolean emailUnique(String email) {
		String query = "SELECT * FROM msuser WHERE UserEmail = ? LIMIT 1";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	private void insertData(String id, String username, String pass, String email, String role, String gender,
			String phoneNumber) {
		String query = "INSERT INTO msuser (UserID, Username, UserPassword, UserEmail, UserRole , UserGender, UserPhoneNumber) VALUES (?, ?, ?, ?, ?, ?, ?)";

		try {
			PreparedStatement ps = Connect.getConnection().prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, username);
			ps.setString(3, pass);
			ps.setString(4, email);
			ps.setString(5, role);
			ps.setString(6, gender);
			ps.setString(7, phoneNumber);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		initialize();
		setComponent();
		eventHandler(primaryStage);

		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();
	}

}
