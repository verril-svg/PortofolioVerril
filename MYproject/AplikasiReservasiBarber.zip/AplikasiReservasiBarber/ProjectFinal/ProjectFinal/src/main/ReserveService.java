package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Reservation;
import model.Service;
import util.Connect;

public class ReserveService extends Application {

	BorderPane bp;
	VBox leftVBox, rightVBox;
	Label rsLabel, userLabel, reserveList, reserveDate, reserveTime;

	MenuBar menuBar;
	Menu fileMenu;
	MenuItem reserveService, customerReservation, logOut;

	TextField reserveTimeTf;
	DatePicker datePicker;
	TableView<Service> tv;
	ListView<String> lv;
	Alert alert;

	Button addBtn, cancelBtn, reserveBtn;

	HBox typeHbox;
	CheckBox hairCut, hairTreatment, hairPerming, hairColoring, hairTattoo;

	String username;
	List<Reservation> reservations;

	public ReserveService() {
		this.username = "null";
	}

	public ReserveService(String username) {
		this.username = (username == null || username.isEmpty()) ? "null" : username;
	}

	private void initialize() {
		bp = new BorderPane();
		reservations = new ArrayList<>();

		menuBar = new MenuBar();
		fileMenu = new Menu("Menu");
		reserveService = new MenuItem("Reserve Service");
		customerReservation = new MenuItem("Customer Reservation");
		logOut = new MenuItem("Log Out");

		rsLabel = new Label("Reserve Service");
		rsLabel.setStyle("-fx-font-size: 25px; -fx-font-weight: bold;");

		userLabel = new Label("User: " + username);

		tv = new TableView<>();
		tv.setPlaceholder(new Label("No services available"));

		TableColumn<Service, String> idColumn = new TableColumn<>("ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

		TableColumn<Service, String> nameColumn = new TableColumn<>("Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

		TableColumn<Service, String> priceColumn = new TableColumn<>("Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

		TableColumn<Service, String> durationColumn = new TableColumn<>("Duration");
		durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));

		tv.getColumns().addAll(idColumn, nameColumn, priceColumn, durationColumn);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		tv.setPrefHeight(350);

		reserveList = new Label("Reserve List");
		reserveList.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");

		reserveDate = new Label("Reservation Date");
		reserveDate.setStyle("-fx-font-size: 12px;");

		reserveTime = new Label("Reservation Time");
		reserveTime.setStyle("-fx-font-size: 12px;");

		hairCut = new CheckBox("Hair Cut");
		hairTreatment = new CheckBox("Hair Treatment");
		hairPerming = new CheckBox("Hair Perming");
		hairColoring = new CheckBox("Hair Coloring");
		hairTattoo = new CheckBox("Hair Tattoo");

		typeHbox = new HBox(10, hairCut, hairTreatment, hairPerming, hairColoring, hairTattoo);
		typeHbox.setAlignment(Pos.CENTER);

		reserveTimeTf = new TextField();
		reserveTimeTf.setPromptText("hh:mm");
		reserveTime.setPrefWidth(250);

		datePicker = new DatePicker();
		datePicker.setPromptText("dd/mm/yyyy");
		datePicker.setPrefWidth(250);

		addBtn = new Button("Add");
		addBtn.setPrefSize(250, 5);

		cancelBtn = new Button("Cancel");
		cancelBtn.setPrefSize(250, 5);

		reserveBtn = new Button("Reserve");
		reserveBtn.setPrefSize(250, 5);

		lv = new ListView<>();
		lv.setPrefHeight(100);

		leftVBox = new VBox(5, rsLabel, userLabel, typeHbox, tv);
		leftVBox.setAlignment(Pos.CENTER_LEFT);

		rightVBox = new VBox(5, reserveList, lv, reserveDate, datePicker, reserveTime, reserveTimeTf, addBtn, cancelBtn,
				reserveBtn);
		rightVBox.setAlignment(Pos.CENTER_LEFT);
	}

	private void setComponent() {
		fileMenu.getItems().addAll(reserveService, customerReservation, logOut);
		menuBar.getMenus().add(fileMenu);
		bp.setTop(menuBar);

		HBox mainContent = new HBox(20, leftVBox, rightVBox);
		mainContent.setAlignment(Pos.CENTER);

		bp.setCenter(mainContent);
	}

	private void eventHandler(Stage primaryStage) {
		addBtn.setOnAction(e -> {
			try {
				Date dates = Date.valueOf(datePicker.getValue());
				String timeInput = reserveTimeTf.getText() + ":00";
				Time time = Time.valueOf(timeInput);

				if (dates == null) {
					showAlert(AlertType.ERROR, "Error Reservation", "Reservation date cannot be empty");
					return;
				}

				if (timeInput.isEmpty()) {
					showAlert(AlertType.ERROR, "Error Reservation", "Reservation time cannot be empty");
					return;
				}

				if (dates.before(new Date(System.currentTimeMillis()))) {
					showAlert(AlertType.ERROR, "Error Reservation", "Reservation date invalid");
					return;
				}

				Time openingTime = Time.valueOf("09:00:00");
				Time closingTime = Time.valueOf("21:00:00");
				if (time.before(openingTime) || time.after(closingTime)) {
					showAlert(AlertType.ERROR, "Error Reservation", "Reservation Time must be between 09:00 - 21:00");
					return;
				}

				Service selected = tv.getSelectionModel().getSelectedItem();
				if (selected == null) {
					showAlert(AlertType.ERROR, "Error Reservation", "There is no service selected");
					return;
				}

				Time end = new Time(time.getTime() + selected.getDuration() * 60 * 1000);
				if (end.after(closingTime)) {
					showAlert(AlertType.ERROR, "Reservation Error", "Reservation Time is over the Barber's open hours");
					return;
				}
				if (!timeUnique(timeInput)) {
					showAlert(AlertType.ERROR, "Reservation Error", "Reservation Time is reserved by someone else");
					return;
				}


				if (isOverlap(dates, time, end)) {
					showAlert(AlertType.ERROR, "Reservation Error",
							"The selected time slot overlaps with an existing reservation.");
					return;
				}

				reservations.add(new Reservation(dates, time, selected));
				lv.getItems().add(selected.getName());

				showAlert(AlertType.INFORMATION, "Reservation Success", "Service successfully added ");

			} catch (IllegalArgumentException ex) {
				showAlert(AlertType.ERROR, "Error Reservation", "Invalid time format");
			}
		});

		cancelBtn.setOnAction(e -> {
			if (lv.getItems().isEmpty()) {
				showAlert(AlertType.ERROR, "Error", "No service selected");
				return;
			}

			lv.getItems().clear();
			reservations.clear();
			showAlert(AlertType.INFORMATION, "Cancellation Success", "Service successfully cancelled");
		});

		reserveBtn.setOnAction(e -> {
			if (reservations.isEmpty()) {
				showAlert(AlertType.ERROR, "Reservation Error", "No reservations to save");
				return;
			}

	
			Stage confirm = new Stage();
			confirm.setTitle("Reserve Confirmation Pop-Up");

			Label rsvLabel = new Label("Reserve confirmation");
			rsvLabel.setAlignment(Pos.TOP_CENTER);

			Label confirmLabel = new Label("Are you sure you want to reserve?");
			confirmLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

			Button yes = new Button("Yes");
			Button no = new Button("No");

			yes.setOnAction(err -> {
				Service selected = tv.getSelectionModel().getSelectedItem();

				if (selected == null) {
					showAlert(AlertType.ERROR, "Reservation Error", "Please select a service.");
					return;
				}

				Date selectedDate;
				Time start;

				try {
					selectedDate = Date.valueOf(datePicker.getValue());
					start = Time.valueOf(reserveTimeTf.getText() + ":00");
				} catch (IllegalArgumentException ex) {
					showAlert(AlertType.ERROR, "Reservation Error", "Invalid date or time format.");
					return;
				}

				int duration = selected.getDuration();
				Time end = new Time(start.getTime() + duration * 60 * 1000);

				String reservationID = generateReservationID();
				String userID = getUserID(username);
				String status = "In progress";

				insertReservationData(reservationID, userID, selectedDate, start, end, status);

				showAlert(AlertType.INFORMATION, "Reservation Success", "Reservation successfully reserved");

				lv.getItems().clear();
				reserveTimeTf.clear();
				datePicker.setValue(null);
				reservations.clear();

				confirm.close();
			});

			no.setOnAction(err -> {
				lv.getItems().clear();
				reserveTimeTf.clear();
				datePicker.setValue(null);
				reservations.clear();

				confirm.close();
			});

			HBox box = new HBox(10, yes, no);
			box.setAlignment(Pos.CENTER);

			VBox vBox = new VBox(10, confirmLabel, box);
			vBox.setAlignment(Pos.CENTER);

			vBox.setStyle("-fx-padding: 50; -fx-background-color: #7a96ae; -fx-border-color: #c4c4c4;");

			Scene scene = new Scene(vBox);
			confirm.setScene(scene);
			confirm.initOwner(primaryStage);
			confirm.showAndWait();
			//
		});

		reserveService.setOnAction(e -> {
			ReserveService rsPage = new ReserveService(username);
			rsPage.start(primaryStage);
		});

		customerReservation.setOnAction(e -> {
			CustomerReservation crPage = new CustomerReservation(username);
			try {
				crPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		logOut.setOnAction(e -> {
			Login loginPage = new Login();
			try {
				loginPage.start(primaryStage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
	}

	private void checkBoxFilter() {
		hairCut.setOnAction(e -> applyFilter());
		hairTreatment.setOnAction(e -> applyFilter());
		hairPerming.setOnAction(e -> applyFilter());
		hairColoring.setOnAction(e -> applyFilter());
		hairTattoo.setOnAction(e -> applyFilter());
	}

	private void applyFilter() {
		List<String> selected = new ArrayList<>();
		if (hairCut.isSelected())
			selected.add("ST001");
		if (hairTreatment.isSelected())
			selected.add("ST004");
		if (hairPerming.isSelected())
			selected.add("ST002");
		if (hairColoring.isSelected())
			selected.add("ST003");
		if (hairTattoo.isSelected())
			selected.add("ST005");

		tv.getItems().clear();

		if (selected.isEmpty()) {
			loadDatabase();
			return;
		}

		String placeholders = String.join(",", selected.stream().map(type -> "?").toArray(String[]::new));
		String query = "SELECT * FROM msservice WHERE ServiceTypeID IN (" + placeholders + ")";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			for (int i = 0; i < selected.size(); i++) {
				ps.setString(i + 1, selected.get(i));
			}

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String id = rs.getString("ServiceID");
				String name = rs.getString("ServiceName");
				Integer price = rs.getInt("ServicePrice");
				Integer duration = rs.getInt("ServiceDuration");
				tv.getItems().add(new Service(id, name, price, duration));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private boolean isOverlap(Date startDate, Time startTime, Time endTime) {
		String query = "SELECT COUNT(*) FROM reservationheader WHERE ReservationStatus = 'In Progress' "
				+ "AND (StartReservationTime < ? AND EndReservationTime > ?) "
				+ "OR (StartReservationTime < ? AND EndReservationTime > ?)";
		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setTimestamp(1, new Timestamp(startDate.getTime() + startTime.getTime()));
			ps.setTimestamp(2, new Timestamp(startDate.getTime() + endTime.getTime()));
			ps.setTimestamp(3, new Timestamp(startDate.getTime() + startTime.getTime()));
			ps.setTimestamp(4, new Timestamp(startDate.getTime() + endTime.getTime()));

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private String generateReservationID() {
		String baseID = "RS001";

		try {
			ResultSet rs = Connect.getConnection().executeQuery(
					"SELECT MAX(CAST(SUBSTRING(ReservationID, 3) AS UNSIGNED)) AS NewID FROM reservationheader");
			if (rs.next()) {
				int newID = rs.getInt("NewID");
				baseID = String.format("RS%03d", newID + 1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return baseID;
	}

	private void showAlert(Alert.AlertType type, String title, String msg) {
		alert = new Alert(type);
		alert.setTitle(title);
		alert.setContentText(msg);
		alert.showAndWait();
	}

	private void insertReservationData(String reservationID, String userID, Date date, Time start, Time end,
			String status) {
		String checkQuery = "SELECT COUNT(*) FROM reservationheader WHERE ReservationID = ?";
		try (PreparedStatement psCheck = Connect.getConnection().prepareStatement(checkQuery)) {
			psCheck.setString(1, reservationID);
			ResultSet rsCheck = psCheck.executeQuery();

			if (rsCheck.next() && rsCheck.getInt(1) > 0) {
				showAlert(AlertType.ERROR, "Reservation Error", "Reservation ID already exists.");
				return;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String query = "INSERT INTO reservationheader "
				+ "(ReservationID, UserID, ReservationDate, StartReservationTime, EndReservationTime, ReservationStatus) "
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, reservationID);
			ps.setString(2, userID);
			ps.setDate(3, date);
			ps.setTime(4, start);
			ps.setTime(5, end);
			ps.setString(6, status);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private String getUserID(String use) {
		String query = "SELECT UserID FROM msuser WHERE Username = ?";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, use);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return rs.getString("UserID");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	private boolean timeUnique(String time) {
		String query = "SELECT * FROM reservationheader WHERE StartReservationTime = ? LIMIT 1";

		try (PreparedStatement ps = Connect.getConnection().prepareStatement(query)) {
			ps.setString(1, time);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		initialize();
		setComponent();
		eventHandler(primaryStage);
		checkBoxFilter();

		Scene scene = new Scene(bp, 800, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("KingsHcut");
		primaryStage.show();
		loadDatabase();
	}

	private void loadDatabase() {
		ResultSet rs = Connect.getConnection().executeQuery("SELECT * FROM msservice");
		try {
			while (rs.next()) {
				String id = rs.getString("ServiceID");
				String name = rs.getString("ServiceName");
				Integer price = rs.getInt("ServicePrice");
				Integer duration = rs.getInt("ServiceDuration");
				tv.getItems().add(new Service(id, name, price, duration));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}