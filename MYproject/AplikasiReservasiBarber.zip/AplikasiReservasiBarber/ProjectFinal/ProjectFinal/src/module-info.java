module ProjekFinal {
	requires javafx.graphics;
	requires java.sql;
	requires javafx.controls;
	exports main;
	
	opens model to javafx.base;
	exports model;
}