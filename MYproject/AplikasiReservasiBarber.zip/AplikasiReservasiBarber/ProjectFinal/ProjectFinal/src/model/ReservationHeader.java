package model;

import java.sql.Time;
import java.util.Date;

public class ReservationHeader {
	private String reservationID, userID;
	private Date date;
	private Time startTime, endTime;
	private String status;

	public ReservationHeader(String reservationID, String userID, Date date, Time startTime, Time endTime,
			String status) {
		super();
		this.reservationID = reservationID;
		this.userID = userID;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.status = status;
	}

	public String getReservationID() {
		return reservationID;
	}

	public void setReservationID(String reservationID) {
		this.reservationID = reservationID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
