package model;

import java.sql.Date;
import java.sql.Time;

public class Reservation {
    private Date date;
    private Time time;
    private Service service;

    public Reservation(Date date, Time time, Service service) {
        this.date = date;
        this.time = time;
        this.service = service;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public boolean overlaps(Date otherDate, Time otherTime) {
        return date.equals(otherDate) && time.equals(otherTime);
    }

    @Override
    public String toString() {
        return service.getName() + " on " + date + " at " + time;
    }
}
