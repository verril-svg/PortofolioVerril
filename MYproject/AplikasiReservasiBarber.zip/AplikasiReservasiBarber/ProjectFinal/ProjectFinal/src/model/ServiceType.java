package model;

public class ServiceType {
	private String typeID, name;

	public ServiceType(String typeID, String name) {
		super();
		this.typeID = typeID;
		this.name = name;
	}

	public String getTypeID() {
		return typeID;
	}

	public void setTypeID(String typeID) {
		this.typeID = typeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
    public String toString() {
        return name;
    }
}
