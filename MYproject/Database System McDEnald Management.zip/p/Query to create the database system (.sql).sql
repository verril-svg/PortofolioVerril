CREATE DATABASE MCdonal
go
USE MCdonal
go

CREATE TABLE Staff(
	StaffID CHAR(5) PRIMARY KEY check (StaffID like 'ST[0-9][0-9][0-9]'),
	  Name VARCHAR(50)  NOT NULL,
	Gender VARCHAR(10) CHECK (Gender IN ('Male', 'Female')) NOT NULL
	
)

CREATE TABLE Customer (
	CustomerID CHAR(5) PRIMARY KEY check (CustomerID like 'CU[0-9][0-9][0-9]'),
    Name VARCHAR(50) NOT NULL,
    Gender VARCHAR(10) CHECK (Gender IN ('Male', 'Female')) NOT NULL,
    Address VARCHAR(100) CHECK (Address LIKE '%Street') NOT NULL,
    PhoneNumber VARCHAR(20) CHECK (PhoneNumber LIKE '+62%') NOT NULL
)


CREATE TABLE ProductType (
    ProductTypeID CHAR(5) PRIMARY KEY check (ProductTypeID like 'PT[0-9][0-9][0-9]'),
    Name VARCHAR(50) NOT NULL
);

CREATE TABLE Product (
    ProductID CHAR(5) PRIMARY KEY CHECK (ProductID LIKE 'PR[0-9][0-9][0-9]'),
    ProductName VARCHAR(50) NOT NULL CHECK (LEN(ProductName) >= 5),
    Price INT NOT NULL,
    ProductTypeID CHAR(5), CONSTRAINT FK_Product_ProductType
    FOREIGN KEY (ProductTypeID) REFERENCES ProductType(ProductTypeID) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT CHK_ProductName_Length CHECK (LEN(ProductName) >= 5)
);
ALTER TABLE Product
ADD CONSTRAINT ProductProductType
FOREIGN KEY (ProductTypeID) REFERENCES ProductType(ProductTypeID);

CREATE TABLE PaymentMethod (
    PaymentMethodID CHAR(5) PRIMARY KEY CHECK (PaymentMethodID like 'PM[0-9][0-9][0-9]'),
    Name VARCHAR(50) NOT NULL
);

ALTER TABLE PaymentMethod
ADD CONSTRAINT FK_PaymentMethodID 
FOREIGN KEY (PaymentMethodID) 
REFERENCES PaymentMethod(PaymentMethodID);

CREATE TABLE Store (
    StoreID CHAR(5) PRIMARY KEY check ( StoreID like 'SO[0-9][0-9][0-9]'),
    Name VARCHAR(100) NOT NULL,
    Address VARCHAR(100) CHECK (Address LIKE '%Street') NOT NULL,
    PhoneNumber VARCHAR(20) CHECK (PhoneNumber LIKE '(021)%') NOT NULL
);
CREATE TABLE headerTransaction (
    TransactionID CHAR(5) PRIMARY KEY  check ( TransactionID like 'TR[0-9][0-9][0-9]'),
    TransactionDate DATE  NOT NULL CHECK (TransactionDate <= GETDATE()) ,
	Quantity INT CHECK (Quantity BETWEEN 1 AND 200) NOT NULL,
    StaffID CHAR(5) FOREIGN KEY REFERENCES Staff(StaffID)  ON UPDATE CASCADE ON DELETE CASCADE ,
	ProductName VARCHAR(50) ,
    CustomerID CHAR(5)FOREIGN KEY REFERENCES Customer(CustomerID)  ON UPDATE CASCADE ON DELETE CASCADE ,
    StoreID CHAR(5) FOREIGN KEY REFERENCES Store(StoreID) ON UPDATE CASCADE ON DELETE CASCADE ,
    PaymentMethodID CHAR(5) FOREIGN KEY REFERENCES PaymentMethod(PaymentMethodID) ON UPDATE CASCADE ON DELETE CASCADE

);
CREATE TABLE TransactionDetail (
    TransactionDetailID CHAR(5) PRIMARY KEY ,
    TransactionID CHAR(5) FOREIGN KEY REFERENCES headerTransaction(TransactionID) ON UPDATE CASCADE ON DELETE CASCADE,
    ProductID  CHAR(5) FOREIGN KEY REFERENCES Product(ProductID) ON UPDATE CASCADE ON DELETE CASCADE,
    Quantity INT CHECK (Quantity BETWEEN 1 AND 200) NOT NULL,
  
);