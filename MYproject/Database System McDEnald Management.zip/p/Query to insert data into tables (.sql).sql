
USE MCdonal
INSERT INTO ProductType  VALUES
('PT001', 'Chicken'),
('PT002', 'Burger'),
('PT003', 'Chicken'),
('PT004', 'Dessert'),
('PT005', 'Chicken'),
('PT006', 'Dessert'),
('PT007', 'Burger'),
('PT008', 'Drinks'),
('PT009', 'Burger'),
('PT010', 'Drinks');

INSERT INTO PaymentMethod VALUES
('PM001', 'Cash'),
('PM002', 'ERIS'),
('PM003', 'Debit Card'),
('PM004', 'EVA'),
('PM005', 'Credit Card'),
('PM006', 'DENA'),
('PM007', 'GePay'),
('PM008', 'E.Saku'),
('PM009', 'SheppePay'),
('PM010', 'Flep');



INSERT INTO Staff VALUES ('ST001','John Doe', 'Male')
INSERT INTO Staff VALUES ('ST002','peter parker', 'Male')
INSERT INTO Staff VALUES ('ST003','Cindy wardo', 'Female')
INSERT INTO Staff VALUES ('ST004','Thomas Sanjoyo', 'Male')
INSERT INTO Staff VALUES ('ST005','Angel  toriyo', 'Female')
INSERT INTO Staff VALUES ('ST006','Olomo Yolawi', 'Male')


INSERT INTO Customer VALUES('CU001', 'Daniel Rapit', 'Male', ' oiindomantap Street','+62 857-7198-3031')
INSERT INTO Customer VALUES('CU002', 'Garit Waudiau', 'Male', ' oiindomantap Street','+62 851-9190-3130')
INSERT INTO Customer VALUES('CU003', 'Michelle jawir', 'Female', 'Street ooogituuyaa Street','+62 877-7770-3230')
INSERT INTO Customer VALUES('CU004', 'Felicia cantik', 'Female', 'Street manikutula Street','+62 889-8888-2261')
INSERT INTO Customer VALUES('CU005', 'Ulta Manti', 'Female', 'Street maniamantap Street','+62 807-9008-3033')

INSERT INTO Product VALUES('PR001', 'Fried Chicken', 200000,'PT001')
INSERT INTO Product VALUES('PR002', 'Cheeseburger',10000,'PT002')
INSERT INTO Product VALUES('PR003', 'Fried Chicken', 200000,'PT003')
INSERT INTO Product VALUES('PR004', 'Ice Cream', 8000,'PT004')
INSERT INTO Product VALUES('PR005', 'Fried Chicken', 8000,'PT005');
INSERT INTO Product VALUES('PR006', 'Ice Cream', 8000,'PT006');
INSERT INTO Product VALUES('PR007', 'Cheeseburger', 10000,'PT007');
INSERT INTO Product VALUES('PR008', 'Ice Cream', 5000,'PT008');
INSERT INTO Product VALUES('PR009', 'Cheeseburger', 10000,'PT009');
INSERT INTO Product VALUES('PR010', 'Ice Cream', 5000,'PT010');

INSERT INTO Store  VALUES
('SO001','McDEnald Downtown', '123 Main Street', '(021)123456789'),
('SO002','McDEnald Park', '456 Park Street', '(021)987654321'),
('SO003','McDEnald Elm', '789 Elm Street', '(021)501234059');

INSERT INTO headerTransaction VALUES ('TR001', '2022-06-15' ,1, 'ST001', 'Fried Chicken', 'CU001', 'SO001', 'PM001')
INSERT INTO headerTransaction VALUES ('TR002', '2022-07-14' ,2, 'ST001', 'Cheeseburger',  'CU001',  'SO001', 'PM002')
INSERT INTO headerTransaction VALUES ('TR003', '2022-03-10',1, 'ST001',  'Fried Chicken', 'CU002', 'SO001', 'PM003')
INSERT INTO headerTransaction VALUES ('TR004', '2022-03-28',3, 'ST002', 'Ice Cream','CU002', 'SO001', 'PM004')
INSERT INTO headerTransaction VALUES ('TR005', '2022-06-28',6, 'ST002', 'Fried Chicken','CU003', 'SO002', 'PM005')
INSERT INTO headerTransaction VALUES ('TR006', '2023-03-28',4, 'ST003', 'Ice Cream','CU003', 'SO002', 'PM006')
INSERT INTO headerTransaction VALUES ('TR007', '2023-03-28',5, 'ST004', 'Cheeseburger','CU004', 'SO002', 'PM007')
INSERT INTO headerTransaction VALUES ('TR008', '2023-12-28',6, 'ST004', 'Ice Cream','CU004', 'SO003', 'PM008')
INSERT INTO headerTransaction VALUES ('TR009', '2023-03-28',8, 'ST005', 'Cheeseburger','CU005', 'SO003', 'PM009')
INSERT INTO headerTransaction VALUES ('TR010', '2023-08-28',10, 'ST006', 'Ice Cream','CU005', 'SO003', 'PM010')


INSERT INTO TransactionDetail VALUES ('TD001', 'TR001', 'PR001', 1);
INSERT INTO TransactionDetail VALUES ('TD002', 'TR002', 'PR002', 2);
INSERT INTO TransactionDetail VALUES ('TD003', 'TR003', 'PR003', 1);
INSERT INTO TransactionDetail VALUES ('TD004', 'TR004', 'PR004', 3);
INSERT INTO TransactionDetail VALUES ('TD005', 'TR005', 'PR005', 6);
INSERT INTO TransactionDetail VALUES ('TD006', 'TR006', 'PR006', 4);
INSERT INTO TransactionDetail VALUES ('TD007', 'TR007', 'PR007', 5);
INSERT INTO TransactionDetail VALUES ('TD008', 'TR008', 'PR008', 6);
INSERT INTO TransactionDetail VALUES ('TD009', 'TR009', 'PR009', 8);
INSERT INTO TransactionDetail VALUES ('TD010', 'TR010', 'PR010', 10);
