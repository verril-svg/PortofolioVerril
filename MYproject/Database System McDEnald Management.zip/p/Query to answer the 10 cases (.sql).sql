
USE MCdonal


-- no 1
SELECT REPLACE(TransactionID, 'R', LEFT(Name, 1))[Transaction ID] , Name [Customer Name], SUM(Quantity) [Total Quantity]
FROM headerTransaction ht JOIN Customer c ON ht.CustomerID = c.CustomerID
WHERE Name LIKE '%a%' AND Gender = 'Female'
GROUP BY TransactionID, Name;


-- no 2
SELECT 
    T.TransactionID,
    C.Name AS CustomerName,
    AVG(T.Quantity) AS AverageQuantity
FROM headerTransaction T 
JOIN Customer C ON T.CustomerID = C.CustomerID
GROUP BY T.TransactionID, C.Name
HAVING 
    DAY(MAX(T.TransactionDate)) > 14 AND
    MONTH(MAX(T.TransactionDate)) > 5;


-- no 3
SELECT 
    PT.ProductTypeID,
    UPPER(PT.Name) AS ProductTypeName,
    COUNT(DISTINCT T.TransactionID) AS TotalProductType,
    SUM(TD.Quantity) AS TotalQuantity
FROM 
    ProductType PT
JOIN 
    Product P ON PT.ProductTypeID = P.ProductTypeID
JOIN 
    TransactionDetail TD ON P.ProductID = TD.ProductID
JOIN 
    headerTransaction T ON TD.TransactionID = T.TransactionID
WHERE 
    PT.Name LIKE '%e%' 
    AND 
    CAST(RIGHT(PT.ProductTypeID, 1) AS INT) % 2 = 0
GROUP BY 
    PT.ProductTypeID, PT.Name;


--no 4
SELECT 
    ht.TransactionID,
    LOWER(CONCAT('Mr. ', c.Name)) AS CustomerName,
    MIN(td.Quantity) AS MinimumPurchase,
    MAX(td.Quantity) AS MaximumPurchase
FROM 
    headerTransaction ht
JOIN 
    Customer c ON ht.CustomerID = c.CustomerID
JOIN 
    TransactionDetail td ON ht.TransactionID = td.TransactionID
WHERE 
    ht.TransactionDate > '2019-01-01'
    AND c.Gender = 'Male'
GROUP BY 
    ht.TransactionID, c.Name;


-- no 5
SELECT 
    HT.TransactionID,
    HT.TransactionDate,
    S.Name AS StaffName,
    CONCAT(TD.ProductID, '-', LEFT(P.ProductName, 1)) AS ProductID_ProductName,
    P.ProductName
FROM 
    headerTransaction HT
JOIN 
    Staff S ON HT.StaffID = S.StaffID
JOIN 
    TransactionDetail TD ON HT.TransactionID = TD.TransactionID
JOIN 
    Product P ON TD.ProductID = P.ProductID
WHERE 
    P.Price > (SELECT AVG(Price) FROM Product) AND
    DAY(HT.TransactionDate) < 16;


-- no 6
SELECT 
    CONVERT(VARCHAR(11), ht.TransactionDate, 106) AS TransactionDate,
    LOWER(C.Name) AS CustomerName,
    SUM(p.Price * td.Quantity) AS TotalPrice
FROM 
    headerTransaction ht
JOIN 
    Customer C ON ht.CustomerID = C.CustomerID
JOIN 
    (
        SELECT 
            td.TransactionID,
            SUM(p.Price * td.Quantity) AS TotalPrice
        FROM 
            TransactionDetail td
        JOIN 
            Product p ON td.ProductID = p.ProductID
        GROUP BY 
            td.TransactionID
    ) transaction_totals ON ht.TransactionID = transaction_totals.TransactionID
JOIN 
    TransactionDetail td ON ht.TransactionID = td.TransactionID
JOIN 
    Product p ON td.ProductID = p.ProductID
WHERE 
    LEN(C.Name) > 7
    AND C.Address LIKE '%i%'
GROUP BY 
    ht.TransactionDate, C.Name;

-- no 7
	SELECT 
    REPLACE(ht.TransactionID, 'R', UPPER(RIGHT(c.Name, 1))) AS TransactionID,
    FORMAT(ht.TransactionDate, 'MMM dd, yyyy') AS TransactionDate,
    CONCAT('Mr. ', c.Name) AS CustomerName,
    SUM(p.Price * td.Quantity) AS TotalPrice
FROM 
    headerTransaction ht
JOIN 
    Customer c ON ht.CustomerID = c.CustomerID
JOIN 
    TransactionDetail td ON ht.TransactionID = td.TransactionID
JOIN 
    Product p ON td.ProductID = p.ProductID
JOIN 
    PaymentMethod pm ON ht.PaymentMethodID = pm.PaymentMethodID
GROUP BY 
    ht.TransactionID, ht.TransactionDate, c.Name, pm.Name -- Including PaymentMethod.Name in the GROUP BY clause
HAVING 
    SUM(p.Price * td.Quantity) < (SELECT AVG(TotalPrice) FROM (
     SELECT SUM(p.Price * td.Quantity) AS TotalPrice
     FROM headerTransaction ht
     JOIN TransactionDetail td ON ht.TransactionID = td.TransactionID
     JOIN Product p ON td.ProductID = p.ProductID
     GROUP BY ht.TransactionID) AS AvgTotalPrice)
     AND LEN(pm.Name) >= 2
ORDER BY 
    ht.TransactionDate;


-- no 8
SELECT 
    ht.TransactionID,
    CONCAT(CASE WHEN c.Gender = 'Male' THEN 'Mr. ' ELSE 'Ms. ' END, c.Name) AS CustomerName,
    c.PhoneNumber AS CustomerTelephoneNumber,
    REPLACE(s.Name, 's', '''s') AS StoreName
FROM 
    headerTransaction ht
JOIN 
    Customer c ON ht.CustomerID = c.CustomerID
JOIN 
    Store s ON ht.StoreID = s.StoreID
WHERE 
    RIGHT(s.PhoneNumber, 1) % 2 = 1 -- Filter stores where the last number in the telephone number is odd
    AND ht.Quantity > (SELECT AVG(Quantity) FROM (
                            SELECT DISTINCT Quantity
                            FROM headerTransaction
                         ) AS AvgQuantity) -- Filter transactions where the quantity is above the average of all unique quantities
GROUP BY 
    ht.TransactionID, c.Name, c.Gender, c.PhoneNumber, s.Name;


-- no 9
CREATE VIEW staff_activeness AS
SELECT 
    ht.TransactionID,
    YEAR(ht.TransactionDate) AS TransactionYear,
    s.Name AS StaffName,
    SUM(td.Quantity) AS TotalQuantity,
    AVG(td.Quantity) AS AverageQuantity
FROM 
    headerTransaction ht
JOIN 
    Staff s ON ht.StaffID = s.StaffID
JOIN 
    TransactionDetail td ON ht.TransactionID = td.TransactionID
WHERE 
    s.Gender = 'Female'
    AND ht.TransactionDate >= DATEADD(YEAR, -6, GETDATE()) -- Transactions in the last 6 years
GROUP BY 
    ht.TransactionID, YEAR(ht.TransactionDate), s.Name;

	select*from staff_activeness


--no 10 
CREATE VIEW payment_method_usage AS
SELECT 
    pm.PaymentMethodID,
    pm.Name AS PaymentMethodName,
    MIN(td.Quantity) AS MinimumQuantity,
    MAX(td.Quantity) AS MaximumQuantity
FROM 
    headerTransaction ht
JOIN 
    PaymentMethod pm ON ht.PaymentMethodID = pm.PaymentMethodID
JOIN 
    TransactionDetail td ON ht.TransactionID = td.TransactionID
WHERE 
    MONTH(ht.TransactionDate) < 5 -- Transactions before the 5th month
    AND LEN(pm.Name) < 5 -- Payment method name length is under 5
GROUP BY 
    pm.PaymentMethodID, pm.Name;


	select*from payment_method_usage