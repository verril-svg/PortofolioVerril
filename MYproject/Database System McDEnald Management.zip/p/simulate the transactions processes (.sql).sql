CREATE TABLE headerTransaction (
    TransactionID CHAR(5) PRIMARY KEY  check ( TransactionID like 'TR[0-9][0-9][0-9]'),
    TransactionDate DATE  NOT NULL CHECK (TransactionDate <= GETDATE()) ,
	Quantity INT CHECK (Quantity BETWEEN 1 AND 200) NOT NULL,
    StaffID CHAR(5) FOREIGN KEY REFERENCES Staff(StaffID)  ON UPDATE CASCADE ON DELETE CASCADE ,
	ProductName VARCHAR(50) ,
    CustomerID CHAR(5)FOREIGN KEY REFERENCES Customer(CustomerID)  ON UPDATE CASCADE ON DELETE CASCADE ,
    StoreID CHAR(5) FOREIGN KEY REFERENCES Store(StoreID) ON UPDATE CASCADE ON DELETE CASCADE ,
    PaymentMethodID CHAR(5) FOREIGN KEY REFERENCES PaymentMethod(PaymentMethodID) ON UPDATE CASCADE ON DELETE CASCADE

);
CREATE TABLE TransactionDetail (
    TransactionDetailID CHAR(5) PRIMARY KEY ,
    TransactionID CHAR(5) FOREIGN KEY REFERENCES headerTransaction(TransactionID) ON UPDATE CASCADE ON DELETE CASCADE,
    ProductID  CHAR(5) FOREIGN KEY REFERENCES Product(ProductID) ON UPDATE CASCADE ON DELETE CASCADE,
    Quantity INT CHECK (Quantity BETWEEN 1 AND 200) NOT NULL,
  
);
INSERT INTO headerTransaction VALUES ('TR001', '2022-06-15' ,1, 'ST001', 'Fried Chicken', 'CU001', 'SO001', 'PM001')
INSERT INTO headerTransaction VALUES ('TR002', '2022-07-14' ,2, 'ST001', 'Cheeseburger',  'CU001',  'SO001', 'PM002')
INSERT INTO headerTransaction VALUES ('TR003', '2022-03-10',1, 'ST001',  'Fried Chicken', 'CU002', 'SO001', 'PM003')
INSERT INTO headerTransaction VALUES ('TR004', '2022-03-28',3, 'ST002', 'Ice Cream','CU002', 'SO001', 'PM004')
INSERT INTO headerTransaction VALUES ('TR005', '2022-06-28',6, 'ST002', 'Fried Chicken','CU003', 'SO002', 'PM005')
INSERT INTO headerTransaction VALUES ('TR006', '2023-03-28',4, 'ST003', 'Ice Cream','CU003', 'SO002', 'PM006')
INSERT INTO headerTransaction VALUES ('TR007', '2023-03-28',5, 'ST004', 'Cheeseburger','CU004', 'SO002', 'PM007')
INSERT INTO headerTransaction VALUES ('TR008', '2023-12-28',6, 'ST004', 'Ice Cream','CU004', 'SO003', 'PM008')
INSERT INTO headerTransaction VALUES ('TR009', '2023-03-28',8, 'ST005', 'Cheeseburger','CU005', 'SO003', 'PM009')
INSERT INTO headerTransaction VALUES ('TR010', '2023-08-28',10, 'ST006', 'Ice Cream','CU005', 'SO003', 'PM010')


INSERT INTO TransactionDetail VALUES ('TD001', 'TR001', 'PR001', 1);
INSERT INTO TransactionDetail VALUES ('TD002', 'TR002', 'PR002', 2);
INSERT INTO TransactionDetail VALUES ('TD003', 'TR003', 'PR003', 1);
INSERT INTO TransactionDetail VALUES ('TD004', 'TR004', 'PR004', 3);
INSERT INTO TransactionDetail VALUES ('TD005', 'TR005', 'PR005', 6);
INSERT INTO TransactionDetail VALUES ('TD006', 'TR006', 'PR006', 4);
INSERT INTO TransactionDetail VALUES ('TD007', 'TR007', 'PR007', 5);
INSERT INTO TransactionDetail VALUES ('TD008', 'TR008', 'PR008', 6);
INSERT INTO TransactionDetail VALUES ('TD009', 'TR009', 'PR009', 8);
INSERT INTO TransactionDetail VALUES ('TD010', 'TR010', 'PR010', 10);


-- Customer baru 
	INSERT INTO Customer 
VALUES ('CU006', 'Alice Johnson', 'Female', '789 Pine Street', '+62 812-3456-7890');

	INSERT INTO Customer 
VALUES ('CU007', 'Madoka ', 'Female', '190 tokyo Street', '+62 800-6666-9880');

INSERT INTO Customer 
VALUES ('CU008', 'Homura Akemi ', 'Female', '198 tokyo Street', '+62 999-9876-9000');

INSERT INTO Customer 
VALUES ('CU009', 'kazuma ', 'male', '198 saitama Street', '+62 880-5661-9908');

INSERT INTO Customer 
VALUES ('CU010', 'Megumin ', 'Female', '198 Shibuya  Street', '+62 009-8987-4435');


INSERT INTO headerTransaction 
VALUES ('TR011', GETDATE(), 2, 'ST001', 'Fried Chicken', 'CU006', 'SO001', 'PM001');

INSERT INTO headerTransaction 
VALUES ('TR012', GETDATE(), 1, 'ST001', 'Ice Cream', 'CU006', 'SO001', 'PM001');

INSERT INTO headerTransaction 
VALUES ('TR013', GETDATE(), 3, 'ST002', 'Cheeseburger', 'CU007', 'SO002', 'PM003');

INSERT INTO headerTransaction 
VALUES ('TR014', GETDATE(), 4, 'ST004', 'Fried Chicken', 'CU008', 'SO001', 'PM001');

INSERT INTO headerTransaction 
VALUES ('TR015', GETDATE(), 1, 'ST006', 'Ice Cream', 'CU009', 'SO003', 'PM003');

INSERT INTO headerTransaction 
VALUES ('TR016', GETDATE(), 3, 'ST005', 'Ice Cream', 'CU010', 'SO003', 'PM004');

INSERT INTO TransactionDetail 
VALUES 
    ('TD011', 'TR011', 'PR001', 2), 
    ('TD012', 'TR012', 'PR004', 1);

	INSERT INTO TransactionDetail VALUES  ('TD013', 'TR013', 'PR002', 3)
	INSERT INTO TransactionDetail VALUES  ('TD014', 'TR014', 'PR003', 4)
	INSERT INTO TransactionDetail VALUES ('TD015', 'TR015', 'PR005', 1) 
    INSERT INTO TransactionDetail VALUES  ('TD016', 'TR016', 'PR010', 3);


	select*from headerTransaction

-- Customer yang ingin melakukan pembaruan pesanan 
------------------------------------------------
UPDATE headerTransaction
SET Quantity = 3
WHERE TransactionID = 'TR001';

UPDATE TransactionDetail
SET Quantity = 3
WHERE TransactionDetailID = 'TD001';
------------------------------------------------
------------------------------------------------
UPDATE headerTransaction
SET Quantity = 4
WHERE TransactionID = 'TR002';

UPDATE TransactionDetail
SET Quantity = 4
WHERE TransactionDetailID = 'TD002';
------------------------------------------------
------------------------------------------------
UPDATE headerTransaction
SET Quantity = 2
WHERE TransactionID = 'TR006';

UPDATE TransactionDetail
SET Quantity = 2
WHERE TransactionDetailID = 'TD006';
------------------------------------------------
------------------------------------------------
UPDATE headerTransaction
SET Quantity = 2
WHERE TransactionID = 'TR015';

UPDATE TransactionDetail
SET Quantity = 2
WHERE TransactionDetailID = 'TD015';
------------------------------------------------
------------------------------------------------
UPDATE headerTransaction
SET Quantity = 5
WHERE TransactionID = 'TR010';

UPDATE TransactionDetail
SET Quantity = 5
WHERE TransactionDetailID = 'TD010';
------------------------------------------------

-- customer yang ingin membatalkan pesanan 
------------------------------------------------
DELETE FROM headerTransaction
WHERE TransactionID = 'TR012';

DELETE FROM TransactionDetail
WHERE TransactionDetailID = 'TD012';
----------------------------------------------
----------------------------------------------
DELETE FROM headerTransaction
WHERE TransactionID = 'TR003';

DELETE FROM TransactionDetail
WHERE TransactionDetailID = 'TD003';
----------------------------------------------
----------------------------------------------
DELETE FROM headerTransaction
WHERE TransactionID = 'TR005';

DELETE FROM TransactionDetail
WHERE TransactionDetailID = 'TD005';
----------------------------------------------
----------------------------------------------
DELETE FROM headerTransaction
WHERE TransactionID = 'TR008';

DELETE FROM TransactionDetail
WHERE TransactionDetailID = 'TD008';
----------------------------------------------
----------------------------------------------
DELETE FROM headerTransaction
WHERE TransactionID = 'TR009';

DELETE FROM TransactionDetail
WHERE TransactionDetailID = 'TD009';
----------------------------------------------